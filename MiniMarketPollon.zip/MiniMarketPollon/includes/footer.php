<footer>
    <p>&copy; <?php echo date('Y'); ?> Minimarket Pollon - Sistema de Gestión</p>
</footer>